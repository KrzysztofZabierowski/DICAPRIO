<p> lista 1 zad 1 lotto </p>
<?php		
	echo '<table border="1">';
	echo '<tr>';
	for($i=1;$i<=5;$i++)
	{
		$a=rand(1,42);
		echo '<td>'.$a.'</td>';
	}
	echo '</tr>';
	echo '</table>';
?>

<p> lista 1 zad 1 multi multi </p>	

<?php		
	echo '<table border="1">';
	for($i=1;$i<=4;$i++)
	{
		echo '<tr>';
		for ($j=1;$j<=5;$j++)
		{
			$a=rand(1,80);
			echo '<td>'.$a.'</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
?>

<p> lista 1 zad 2 tabliczka mnożenia </p>	

<?php		
	echo '<table border="1">';
	for($i=1;$i<=10;$i++)
	{
		if($i%2==0)
			echo '<tr class="pierwszy">';
		else 
			echo '<tr class="drugi">';
		for ($j=1;$j<=10;$j++)
		{
			echo '<td>'.$i*$j.'</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
?>

<p> lista 1 zad 2 tabliczka mnożenia </p>	

<?php		
	echo '<table border="1">';
	for($i=1;$i<=10;$i++)
	{
		
		echo '<tr class="pierwszy">';
		for ($j=1;$j<=10;$j++)
		{
			if(($i+$j)%2==0)
			echo '<td class="pierwszy">'.$i*$j.'</td>';
		else 
			echo '<td class="drugi">'.$i*$j.'</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
?>
