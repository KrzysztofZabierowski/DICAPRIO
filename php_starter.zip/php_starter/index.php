<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="style.css" />	
	<title> Nazwa projektu </title>
</head>

<body>
	
	<div id="top">
		<h2>Nazwa projektu</h2>
		<h5>Projekt Iksa Ygrekowskiego</h5>
	</div>
	
	<div id="con">
		<div id="menu">
			<strong>MENU:</strong>
			<ul class="nawigacja">
				<li><a href="index.php">Start</a></li>			
			</ul>
			
		
		</div>
		

		
		<div id="tresc">
			Witaj na stronie .....
		</div>
	
		<div id="sub">
			<?php
			/*require_once('reklamy.php');*/
			/*require_once('losowy_cytat.php'); */
			/*require_once('lotto.php');*/
			/*require_once('data.php'); */
			/*require_once('slowniczek.php'); */
			?>
		</div>
	
	</div>
	
	<div id="footer">
		&copy; ...
		<?php
			require_once('1instrukcje.php');
			require_once('2funkcje.php');
			require_once('3tablice.php');
			require_once('4tabliceAsocjacyjne.php');
		?>
	</div>
	
</body>


</html>
