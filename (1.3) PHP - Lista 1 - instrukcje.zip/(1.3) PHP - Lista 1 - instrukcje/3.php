<?php
echo '<table cellspacing="0"">';
for($i = 1; $i < 11; $i ++) {
  echo '<tr>';
  for($ii = 1; $ii < 11; $ii ++) {
    if(($i + $ii) % 2 == 0)
      echo '<td style="border: 1px solid #000; width: 40px; height: 40px; background: #ffeab0;">';
    else
      echo '<td style="border: 1px solid #000; width: 40px; height: 40px;background: #afddde;">';
  }
  echo '</td>';
}
echo '</table><br>';
?>