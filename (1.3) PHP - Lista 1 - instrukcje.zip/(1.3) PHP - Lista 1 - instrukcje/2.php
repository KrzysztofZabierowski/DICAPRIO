<?php
echo '<table cellspacing="0" cellpadding="10">';
for($i = 1; $i < 11; $i ++) {
  if($i % 2 == 0)
    echo '<tr style="background: #ffeab0;">';
  else
    echo '<tr style="background: #afddde;">';

  for($ii = 1; $ii < 11; $ii ++) {
    echo '<td style="border: 1px solid #000;">'.($i * $ii).'</td>';
  }
  echo '</tr>';
}
echo '</table><br>';
?>