<?php
echo '<h2> Lotto </h2>
      <table style="border: 1px solid #000;"><tr>';
for($i = 0; $i < 6; $i ++) {
  $a=rand(1,49);
  echo '<td style="border: 1px solid #000;">'.$a.'</td>';
}
echo '</tr></table><br>';


echo '<h2> Mini-lotto </h2>
      <ul style="list-style: circle;">';
for($i = 0; $i < 5; $i ++) {
  $b=rand(1,42);
  echo '<li>'.$b.'</li>';
}
echo '</ul><br>';


echo '<h2> Multi-multi </h2>
      <table style="border: 1px solid #000;">';
for($i = 0; $i < 4; $i ++) {
  echo '<tr>';
  for($ii = 0; $ii < 5; $ii ++) {
    $c=rand(1,80);
    echo '<td style="border: 1px solid #000;">'.$c.'</td>';
  }
  echo '</tr>';
}
echo '</table><br>';
?>