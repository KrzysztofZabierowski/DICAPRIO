<?php
  $a = 7;
  $b = 7.0;

  if($a === $b)
    echo 'Zmienne są takie same.';
  else
    echo 'Zmienne NIE są takie same.';
?>
