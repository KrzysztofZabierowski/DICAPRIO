<?php
  $tab = array('Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień');
  $il = 0;

  foreach($tab as $i) {
    echo $i.'<br>';
    $il ++;
  }
  echo '<br>'.$il;
?>
