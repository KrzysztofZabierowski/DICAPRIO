<?php
  define('tworcaPHP', 'Rasmus Lerdorf');
  echo '<h1 style="text-align: center;">Twórcą PHP jest <span style="font-style: italic;">'.tworcaPHP.'</span></h1>';
?>
