<?php
  $kolor = 'zielony';

  switch($kolor) {
    case 'zielony':
      echo '<h1 style="color: #0f0;">Mój ulubiony kolor</h1>';
      break;
    case 'czerwony':
      echo '<h1 style="color: #f00;">Mój ulubiony kolor</h1>';
      break;
    case 'niebieski':
      echo '<h1 style="color: #00f;">Mój ulubiony kolor</h1>';
      break;
    default:
      echo '<h1>Podano błędny kolor.<h1>';
}
?>
