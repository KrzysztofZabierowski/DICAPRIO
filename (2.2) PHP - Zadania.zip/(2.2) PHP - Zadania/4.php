<?php
  $p = '%';
  for($i = 0; $i < 100; $i ++)
    echo $p;
?>
