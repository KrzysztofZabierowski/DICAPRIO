<?php
  if(date('H') > 18)
    echo 'Dobry wieczór.';
  else
    echo 'Dzień dobry.';
?>
