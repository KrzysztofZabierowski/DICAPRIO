<?php
function r() {
  $a = rand(1, 100);

  if($a <= 40)
    echo '<img src="r1.png" alt="Reklama 1">';
  else if($a <= 80)
    echo '<img src="r2.png" alt="Reklama 2">';
}

function c() {
  $a = rand(0,255);
  return $a;
}
  
  $r = c();
  $g = c();
  $b = c();
  
  r();
  echo '<p style="color: rgb('.$r.','.$g.','.$b.');">SLOGAN</p>';



?>