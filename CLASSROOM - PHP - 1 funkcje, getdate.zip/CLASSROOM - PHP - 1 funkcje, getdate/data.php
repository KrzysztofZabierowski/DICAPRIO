<?php
  function m($date) {
    if("$date[month]" == 'January')
      return 'stycznia';
    if("$date[month]" == 'February')
      return 'lutego';
    if("$date[month]" == 'March')
      return 'marca';
    if("$date[month]" == 'April')
      return 'kwietnia';
    if("$date[month]" == 'May')
      return 'maja';
    if("$date[month]" == 'June')
      return 'czerwca';
    if("$date[month]" == 'July')
      return 'lipca';
    if("$date[month]" == 'August')
      return 'sierpnia';
    if("$date[month]" == 'September')
      return 'września';
    if("$date[month]" == 'October')
      return 'października';
    if("$date[month]" == 'November')
      return 'listopada';
    if("$date[month]" == 'December')
      return 'grudnia';
  }
  function d($date) {
    if("$date[wday]" == 0)
      return 'Niedziela';
    if("$date[wday]" == 1)
      return 'Poniedziałek';
    if("$date[wday]" == 2)
      return 'Wtorek';
    if("$date[wday]" == 3)
      return 'Środa';
    if("$date[wday]" == 4)
      return 'Czwartek';
    if("$date[wday]" == 5)
      return 'Piątek';
    if("$date[wday]" == 6)
      return 'Sobota';
  }

$date = getdate();
$m = m(getdate());
$d = d(getdate());

  echo "$date[mday] $m $date[year] tj $d";

?>