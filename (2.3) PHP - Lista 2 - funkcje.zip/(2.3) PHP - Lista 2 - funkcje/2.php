<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Zadanie 2 - Lista 2 - funkcje</title>
  <?php
  function f() {
    $a = rand(1,3);
    
    if($a == 1)
      echo 'r';
    else if($a == 2)
      echo 'g';
    else 
      echo 'b';
  }
  
?>
</head>
<style>
  .r{
    background: #f00;
  }
  .g{
    background: #0f0;
  }
  .b{
    background: #00f;
  }
  div{
    width: 500px;
    height: 200px;
  }
</style>
<body>
  <div class="<?php f() ?>">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius sapiente labore adipisci, suscipit amet error inventore nulla libero veritatis itaque, quos sunt earum? Mollitia minus rem nemo non, cum molestiae.</div>
  <div class="<?php f() ?>">Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique recusandae, eos, quo fuga itaque temporibus culpa repudiandae accusamus officiis obcaecati assumenda magni cumque neque incidunt qui nam iure vitae iste.</div>
</body>
</html>
