<?php
  function f() {
    $a = rand(0,255);
    return $a;
  }

  for($i = 0; $i < 18; $i ++) {
    $r = f();
    $g = f();
    $b = f();
    
    echo '<div style="height: 50px; width: '.($r * 5).'px; background: rgb('.$r.','.$g.','.$b.');"></div>';
  }
?>