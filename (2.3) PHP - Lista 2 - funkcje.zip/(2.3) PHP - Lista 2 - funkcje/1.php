<?php
  function reklama1() {
    echo '<img src="r1.png" alt="Reklama 1">';
  }
  function reklama2() {
    echo '<img src="r2.png" alt="Reklama 2">';
  }
  function reklama3() {
    echo '<img src="r3.png" alt="Reklama 3">';
  }

  $a = rand(1,100);

  if($a <= 50)
    reklama1();
  else if($a <= 70)
    reklama2();
  else if($a <= 75)
    reklama3();
?>