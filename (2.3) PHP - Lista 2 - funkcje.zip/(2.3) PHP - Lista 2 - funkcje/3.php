<?php
  function f() {
    $a = rand(0,255);
    return $a;
  }

  $r = f();
  $g = f();
  $b = f();

  echo '<div style="background: rgb('.$r.','.$g.','.$b.'); width: 1200px; height: 1200px;"></div>'
?>