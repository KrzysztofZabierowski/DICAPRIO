<?php 
  $a = 1;
  $b = 0;

  echo 'Wynik dzielenia liczb wynosi: '.@($a/$b);
?>