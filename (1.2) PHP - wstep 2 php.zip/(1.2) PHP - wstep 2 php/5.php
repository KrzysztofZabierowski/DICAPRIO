<?php
  $kolor = 'zielony';

  switch($kolor){
    case 'zielony':
      echo 'kolor <span style="color: #0f0;">zielony</span>';
      break;
    case 'czerwony':
      echo 'kolor <span style="color: #f00;">czerwony</span>';
      break;  
    case 'niebieski':
      echo 'kolor <span style="color: #00f;">niebieski</span>';
      break;
    case 'żółty':
      echo 'kolor <span style="color: #ff0;">żółty</span>';
      break;
    case 'turkusowy':
      echo 'kolor <span style="color: #0ff;">turkusowy</span>';
      break;
    case 'fioletowy':
      echo 'kolor <span style="color: #f0f;">fioletowy</span>';
      break;
    case 'czarny':
      echo 'kolor <span style="color: #000;">czarny</span>';
      break;
    case 'biały':
      echo 'kolor <span style="color: #fff;">biały</span>';
      break;
  }


?>
