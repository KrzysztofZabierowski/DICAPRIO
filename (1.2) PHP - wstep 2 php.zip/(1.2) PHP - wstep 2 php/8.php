<?php
  for($i = 1; $i <= 10; $i ++) {
    for($ii = 1; $ii <= 10; $ii ++)
      echo ($i * $ii)."\t\t\t";
    echo '<br>';
  }
?>