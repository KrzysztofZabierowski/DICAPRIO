<?php 
  $a = 3;
  $b = 4;
  $c = 5;

  if(($a + $b > $c) && ($a + $c > $b) && ($b + $c > $a)) {
    echo 'Z podanych boków '.$a.', '.$b.', '.$c.' można ułożyć trójkąt. ';
    if($a == $b && $a == $c)
      echo 'Podany trójkąt jest równoboczny';
    else if($a == $b || $a == $c || $b == $c)
            echo 'Podany trójkąt jest równoramienny';
        else
            echo 'Podany trójkąt jest różnoboczny';
  }
  else
    echo 'Z podanych boków '.$a.', '.$b.', '.$c.' NIE można ułożyć trójkąta. ';
?>