<?php 
  // 0-49 dop
  // 50-66 dst
  // 67-83 db
  // 84-100 bdb

  $punkty = 30;

  if($punkty < 50)
    echo 'Dopuszczający';
  else if($punkty < 67)
    echo 'Dostateczny';
  else if ($punkty < 84)
    echo 'Dobry';
  else if($punkty <= 100)
    echo 'Bardzo dobry';
  else 
    echo 'Podana ilość punktów jest niewłaściwa';
?>