<?php
  for($i = 0; $i < 10; $i ++)
    print('*');

  echo '<br><br><br>';

  for($i = 0; $i < 6; $i ++) {
    for($ii = 0; $ii < ($i + 1); $ii ++)
      print('*');
    echo '<br>';
  }
?>