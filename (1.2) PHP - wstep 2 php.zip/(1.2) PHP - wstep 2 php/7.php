<?php
  for($i = 21; $i < 30; $i += 2)
    echo $i.'<br>';

?>